SMODS.Back {
    key = 'trickery_deck',
    pos = { x = 5, y = 0 },
    config = {
      vouchers = { "v_overstock_norm" , "v_overstock_plus" },
},
    loc_txt = {
        name = 'Trickery Deck',
        text = {
            [1] = 'Start the run with an {C:red}Eternal{} {C:attention}Showman{}',
            [2] = 'and both {C:attention}Overstock{} Vouchers'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
     apply = function(self, back)
            G.E_MANAGER:add_event(Event({
                  func = function()
                      play_sound('timpani')
                      if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                          G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                      local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_ring_master' })
                          new_joker:add_sticker('eternal', true)
                          G.GAME.joker_buffer = 0
                      end
                      return true
                  end
              }))
    end
}