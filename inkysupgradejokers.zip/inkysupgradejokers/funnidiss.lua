if JokerDisplay then
    local flash = JokerDisplay.Definitions

    flash["j_inkysupg_jokeezer"] = {
        text = {
            { text = "+" },
            { ref_table = "card.joker_display_values", ref_value = "mult", retrigger_type = "mult" }
        },
        text_config = { colour = G.C.MULT },
        calc_function = function(card)
            card.joker_display_values.mult = 0.25 * ((G.deck and G.deck.cards) and #G.deck.cards or 52)
        end
    }
    flash["j_inkysupg_Reversefib"] = {
        text = {
            { ref_table = "card.joker_display_values", ref_value = "counter", retrigger_type = "mult" },
            { text = "x" },
            { ref_table = "card.ability.extra",        ref_value = "chips",   retrigger_type = "mult", colour = G.C.CHIPS }
        },
        reminder_text = {
            { ref_table = "card.joker_display_values", ref_value = "localized_text" },
        },
        calc_function = function(card)
            local counter = 0
            local text, _, scoring_hand = JokerDisplay.evaluate_hand()
            if text ~= 'Unknown' then
                for _, scoring_card in pairs(scoring_hand) do
                    if scoring_card:get_id() and scoring_card:get_id() == 4 or scoring_card:get_id() == 6 or scoring_card:get_id() == 7
                        or scoring_card:get_id() == 9 or scoring_card:get_id() == 10 then
                        counter = counter + 1
                    end
                end
            end
            card.joker_display_values.counter = counter
            card.joker_display_values.localized_text = "(4,6,7,9,10)"
        end

    }
    flash["j_inkysupg_prescriptionlabel"] = {
        text = {
            { text = "+" },
            { ref_table = "card.ability.extra", ref_value = "Chip", retrigger_type = "mult", }
        },
        text_config = { colour = G.C.CHIPS },
        reminder_text = {
            { text = "(3, 4)", colour = G.C.UI.TEXT_INACTIVE }
        },
    }

    flash["j_inkysupg_officersid"] = {
        text = {
            {
                border_nodes = {
                    { text = "X" },
                    { ref_table = "card.joker_display_values", ref_value = "x_mult", retrigger_type = "mult" }
                },
                border_colour = G.C.ORANGE
            }
        },
        reminder_text = {
            { text = "(" },
            { ref_table = "card.joker_display_values", ref_value = "wid"},
            { text = "/5)" },
        },
        calc_function = function(card)
            card.joker_display_values.wid = card.ability.extra.wid or 0
            card.joker_display_values.active = card.ability.extra.wid and card.ability.extra.wid >= 5
            card.joker_display_values.x_mult = card.joker_display_values.active and card.ability.extra.blind_size or 1
        end
    }

    flash["j_inkysupg_flashchip"] = {
        text = {
            { text = "+" },
            { ref_table = "card.ability.extra", ref_value = "chips", retrigger_type = "mult" }
        },
        text_config = { colour = G.C.CHIPS },
    }
    flash["j_inkysupg_balancedallas"] = { -- i had to be babied out of this one gng
        text = {
            {
                border_nodes = {
                    { text = "X" },
                    { ref_table = "card.joker_display_values", ref_value = "x_mult", retrigger_type = "exp" }
                },
                border_colour = G.C.PURPLE
            }
        },
        extra = {
            {
                { text = "(" },
                { ref_table = "card.joker_display_values", ref_value = "odds" },
                { text = ")" },
            }
        },
        reminder_text = {
            { text = "(Ace,10,9,8,7,6,5,4,3,2)" },
        },
        extra_config = { colour = G.C.GREEN, scale = 0.3 },
        calc_function = function(card)
            local mult = 0
            local text, _, scoring_hand = JokerDisplay.evaluate_hand()
            if text ~= 'Unknown' then
                for _, scoring_card in pairs(scoring_hand) do
                    if scoring_card:get_id() and not (scoring_card:get_id() == 11 or scoring_card:get_id() == 12 or scoring_card:get_id() == 13) then
                        mult = mult + 1
                    end
                end
            end
            card.joker_display_values.x_mult = card.ability.extra.Xmult ^ mult
            local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds,
                'j_inkysupg_balancedallas')
            card.joker_display_values.odds = localize { type = 'variable', key = "jdis_odds", vars = { numerator, denominator } }
        end
    }
    flash["j_inkysupg_pipes"] = { -- comy's gonna solo this
        text = {
            { text = "+",                              colour = G.C.CHIPS },
            { ref_table = "card.joker_display_values", ref_value = "chips", colour = G.C.CHIPS, retrigger_type = "mult" },
            { text = " +",                             colour = G.C.MULT },
            { ref_table = "card.joker_display_values", ref_value = "mult",  colour = G.C.MULT,  retrigger_type = "mult" }
        },
        reminder_text = {
            { text = "(" },
            { ref_table = "card.joker_display_values", ref_value = "yes_card_rank", colour = G.C.GREEN },
            { text = "/" },
            { ref_table = "card.joker_display_values", ref_value = "no_card_rank", colour = G.C.MULT },
            { text = ")" }
        },
        calc_function = function(card)
            local chips, mult = 0, 0
            local text, _, scoring_hand = JokerDisplay.evaluate_hand()
            local rank_found = false
            local norank_found = false

            if text ~= 'Unknown' then
                for _, scoring_card in pairs(scoring_hand) do
                    if not scoring_card.debuff and scoring_card:get_id() and scoring_card:get_id() == G.GAME.current_round.NoRank_card.id then
                        norank_found = true
                    end
                    if not scoring_card.debuff and scoring_card:get_id() and scoring_card:get_id() == G.GAME.current_round.YesRank_card.id then 
                        rank_found = true
                    end
                    if rank_found and not scoring_card.debuff and not norank_found then
                        local retriggers = JokerDisplay.calculate_card_triggers(scoring_card, scoring_hand)
                        chips = chips + card.ability.extra.chips * retriggers
                        mult = mult + card.ability.extra.mult * retriggers
                    end
                end
            end
            card.joker_display_values.chips = chips
            card.joker_display_values.mult = mult
            card.joker_display_values.no_card_rank = G.GAME.current_round.NoRank_card.rank
            card.joker_display_values.yes_card_rank = G.GAME.current_round.YesRank_card.rank
        end
    }
end
