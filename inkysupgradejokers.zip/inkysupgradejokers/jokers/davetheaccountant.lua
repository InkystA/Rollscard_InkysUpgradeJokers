SMODS.Joker{ --Dave the Accountant
    key = "davetheaccountant",
    config = {
        extra = {
            money÷10 = 1,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'Dave the Accountant',
        ['text'] = {
            [1] = 'Spawn a {C:dark_edition}Negative{} {C:attention}To the Moon{} and',
            [2] = 'a {C:dark_edition}Negative{} {C:attention}Monedia{} when you defeat the boss blind.',
            [3] = '{X:red,C:white}^0.01{} for every {C:money}$10{}',
            [4] = '{C:inactive,s:0.8}(Currently {X:red,C:white,s:0.8}^#2#{}{C:inactive,s:0.8} Mult){}',
            [5] = '{C:inactive,s:0.6}(I\'m not paid enough for this...){}',
            [6] = '{X:money,C:white}{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 40,
    rarity = "inkysupg_ascended",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 7,
        y = 10
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
           
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.ignore, card.ability.extra.money÷10 + ((math.floor(lenient_bignum(G.GAME.dollars / 10)) or 0)) * 0.01}}
    end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                e_mult = card.ability.extra.money÷10 + (math.floor(lenient_bignum(G.GAME.dollars / 10))) * 0.01
            }
        end
    if context.end_of_round and context.main_eval and G.GAME.blind.boss  and not context.blueprint then
        return {
            func = function()
                
                local created_joker = true
                G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_to_the_moon' })
                    if joker_card then
                        joker_card:set_edition("e_negative", true)
                        
                    end
                    
                    return true
                    end
                }))
                
                if created_joker then
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                end
                return true
                end,
                extra = {
                func = function()
                    
                    local created_joker = true
                    G.E_MANAGER:add_event(Event({
                    func = function()
                        local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_inkysupg_monedia' })
                        if joker_card then
                            joker_card:set_edition("e_negative", true)
                            
                        end
                        
                        return true
                        end
                    }))
                    
                    if created_joker then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                    end
                    return true
                    end,
                    colour = G.C.BLUE
                }
            }
        end
    end
}