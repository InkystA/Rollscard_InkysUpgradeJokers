SMODS.Joker{ --Diminutive Joker
    key = "diminutivejoker",
    config = {
        extra = {
            chip = 1
        }
    },
    loc_txt = {
        ['name'] = 'Diminutive Joker',
        ['text'] = {
            [1] = '{C:blue,s:0.5}+1{} {s:0.5}chips if played hand contains at least {C:attention,s:0.5}4{} {s:0.5}unscored cards{}',
            [2] = '{s:0.5}increase by 1 when condition succeds{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 6
    },
    display_size = {
        w = 71 * 0.1, 
        h = 95 * 0.1
    },
    cost = 1,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["inkysupg_inkysupg_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (#context.full_hand - #context.scoring_hand) >= 4 then
                local chip_value = card.ability.extra.chip
                card.ability.extra.chip = (card.ability.extra.chip) + 1
                return {
                    chips = chip_value
                }
            end
        end
    end
}