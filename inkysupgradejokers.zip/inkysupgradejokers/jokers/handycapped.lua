SMODS.Joker{ --Handy-Capped
    key = "handycapped",
    config = {
        extra = {
            repetitions = 5,
            echips = 1.1
        }
    },
    loc_txt = {
        ['name'] = 'Handy-Capped',
        ['text'] = {
            [1] = 'Disable the Boss Blind {C:attention}17{} times',
            [2] = 'Create {C:attention}5{} Double Tags whenever a boss is {C:attention}defeated{}',
            [3] = 'All {C:red}non{}-{C:clubs}clubs{} give {X:chips,C:white}^1.1{} Chips'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 40,
    rarity = "inkysupg_ascended",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    
    calculate = function(self, card, context)
    if context.end_of_round and context.main_eval and G.GAME.blind.boss  and not context.blueprint then
        if true then
            for i = 1, card.ability.extra.repetitions2 do
                    SMODS.calculate_effect({func = function()
                        G.E_MANAGER:add_event(Event({
                        func = function()
                            local tag = Tag("tag_double")
                            if tag.name == "Orbital Tag" then
                                local _poker_hands = {}
                                for k, v in pairs(G.GAME.hands) do
                                    if v.visible then
                                        _poker_hands[#_poker_hands + 1] = k
                                    end
                                end
                                tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                            end
                            tag:set_ability()
                            add_tag(tag)
                            play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                            return true
                            end
                        }))
                        return true
                        end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Created Tag!", colour = G.C.GREEN})
                    end
                end
            end
            if context.individual and context.cardarea == G.play  then
                if not (context.other_card:is_suit("Clubs")) then
                    return {
                        e_chips = card.ability.extra.echips
                    }
                end
            end
        end
}