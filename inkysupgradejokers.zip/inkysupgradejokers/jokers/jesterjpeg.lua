SMODS.Joker{ --JESTER.JPEG
    key = "jesterjpeg",
    config = {
        extra = {
            xmukt = 4
        }
    },
    loc_txt = {
        ['name'] = 'JESTER.JPEG',
        ['text'] = {
            [1] = 'WHEN CARD IS {C:attention}SCORED{} > {X:red,C:white}X#1#{} MULT,',
            [2] = 'MULTIPLY VALUE FROM {X:red,C:white}???{} TO {X:red,C:white}???{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["inkysupg_inkysupg_jokers"] = true },
    soul_pos = {
        x = 5,
        y = 10
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.xmukt}}
    end,

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            local xmukt_value = card.ability.extra.xmukt
            card.ability.extra.xmukt = (card.ability.extra.xmukt) * pseudorandom('xmukt_5a7b2f97', 0.01, 9.99)
            return {
                Xmult = xmukt_value
            }
        end
    end
}