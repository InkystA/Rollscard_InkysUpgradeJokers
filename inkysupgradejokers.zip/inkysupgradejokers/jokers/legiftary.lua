SMODS.Joker{ --Donum Scelerisque
    key = "legiftary",
    config = {
        extra = {
            Sellval = 2,
            all_jokers = 0
        }
    },
    loc_txt = {
        ['name'] = 'Donum Scelerisque',
        ['text'] = {
            [1] = '{C:attention}Add{} {C:money}$#1#{} of {C:attention}sell value{} to each Joker',
            [2] = '{C:inactive}(Is that it? A legendary wasted for THIS???){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 8,
        y = 8
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
           
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.Sellval}}
    end,

    set_ability = function(self, card, initial)
        card:set_edition("e_negative", true)
    end,

    
    calculate = function(self, card, context)
    if context.end_of_round and context.game_over == false and context.main_eval  then
        local Sellval_value = card.ability.extra.Sellval
        return {
            func = function()
                for i, target_card in ipairs(G.jokers.cards) do
                    if target_card.set_cost then
                        target_card.ability.extra_value = (card.ability.extra_value or 0) + Sellval_value
                        target_card:set_cost()
                    end
                end
                return true
                end,
                message = "All Jokers +"..tostring(Sellval_value).." Sell Value",
                extra = {
                func = function()
                    card.ability.extra.Sellval = (card.ability.extra.Sellval) * 2
                    return true
                    end,
                    colour = G.C.MULT
                }
            }
        end
    end
}