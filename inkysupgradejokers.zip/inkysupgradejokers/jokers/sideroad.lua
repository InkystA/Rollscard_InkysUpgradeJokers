SMODS.Joker{ --Side Road
    key = "sideroad",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Side Road',
        ['text'] = {
            [1] = 'Straights need to be done with {C:attention}6{} cards,',
            [2] = '{C:attention}+2{} Hand Size'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "inkysupg_workinprogress",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["inkysupg_inkysupg_jokers"] = true }
}