SMODS.Joker{ --Smour Shortance
    key = "sssf",
    config = {
        extra = {
            reduction_value = 1,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Smour Shortance',
        ['text'] = {
            [1] = 'I\'ll let {C:attention}You{} figure it out just by',
            [2] = 'the name alone. No help at all.',
            [3] = '{C:inactive,s:0.7}(Psst, its Four Fingers, Shortcut.{}',
            [4] = '{C:inactive,s:0.7}Smeared and Séance together!){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 2,
        y = 5
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
           
          )
          and true
      end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if context.scoring_name == "Straight Flush" then
                for i = 1, math.min(undefined, G.consumeables.config.card_limit - #G.consumeables.cards) do
                    G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.4,
                    func = function()
                        play_sound('timpani')
                        SMODS.add_card({ set = 'Spectral', })                            
                        card:juice_up(0.3, 0.5)
                        return true
                        end
                    }))
                end
                delay(0.6)
                return {
                    message = created_consumable and localize('k_plus_spectral') or nil
                }
            end
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        -- Combine suits effect enabled
        -- Combine suits effect enabled
        -- Flush/Straight requirements reduced by 1
        -- Shortcut straights enabled
    end,

    remove_from_deck = function(self, card, from_debuff)
        -- Combine suits effect disabled
        -- Combine suits effect disabled
        -- Flush/Straight requirements restored
        -- Shortcut straights disabled
    end
}


local smods_four_fingers_ref = SMODS.four_fingers
function SMODS.four_fingers()
    if next(SMODS.find_card("j_inkysupg_sssf")) then
        return 4
    end
    return smods_four_fingers_ref()
end
local smods_shortcut_ref = SMODS.shortcut
function SMODS.shortcut()
    if next(SMODS.find_card("j_inkysupg_sssf")) then
        return true
    end
    return smods_shortcut_ref()
end
local card_is_suit_ref = Card.is_suit
function Card:is_suit(suit, bypass_debuff, flush_calc)
    local ret = card_is_suit_ref(self, suit, bypass_debuff, flush_calc)
    if not ret and not SMODS.has_no_suit(self) then
        if next(SMODS.find_card("j_inkysupg_sssf")) then
            -- If checking for Spades and card is Clubs, return true
            if suit == "Spades" and self.base.suit == "Clubs" then
                ret = true
            end
            -- If checking for Clubs and card is Spades, return true
            if suit == "Clubs" and self.base.suit == "Spades" then
                ret = true
            end
            -- If checking for Diamonds and card is Hearts, return true
            if suit == "Diamonds" and self.base.suit == "Hearts" then
                ret = true
            end
            -- If checking for Hearts and card is Diamonds, return true
            if suit == "Hearts" and self.base.suit == "Diamonds" then
                ret = true
            end
        end
    end
    return ret
end