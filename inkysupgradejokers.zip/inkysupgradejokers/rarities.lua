SMODS.Rarity {
    key = "ascended",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('cac222'),
    loc_txt = {
        name = "Ascended"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "curse",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.05,
    badge_colour = HEX('101010'),
    loc_txt = {
        name = "Curse"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "workinprogress",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('0a1d32'),
    loc_txt = {
        name = "WORKINPROGRESS"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}